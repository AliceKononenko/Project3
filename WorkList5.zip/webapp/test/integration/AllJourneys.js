/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"jetCources/WorkList/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"jetCources/WorkList/test/integration/pages/Worklist",
	"jetCources/WorkList/test/integration/pages/Object",
	"jetCources/WorkList/test/integration/pages/NotFound",
	"jetCources/WorkList/test/integration/pages/Browser",
	"jetCources/WorkList/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "jetCources.WorkList.view."
	});

	sap.ui.require([
		"jetCources/WorkList/test/integration/WorklistJourney",
		"jetCources/WorkList/test/integration/ObjectJourney",
		"jetCources/WorkList/test/integration/NavigationJourney",
		"jetCources/WorkList/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});