sap.ui.define([], function() {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function(sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		formatColumnHighLight: function(sUser) {
			if (sUser === 'LAB1000012') {
				return "Success";
			} else {
				return "None";
			}
		},

		formatRadioButton: function(sValue) {
			return (sValue !== null) ? parseInt(sValue, 10) - 1 : -1;

		},

		formatCreationInfo: function(sUser, dDate) {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy/MM/dd"
			});
			var sDate = oDateFormat.format(dDate);
			return this.getModel("i18n").getResourceBundle().getText("labelCreatedBy") + " " + sUser 
			+ ", " + this.getModel("i18n").getResourceBundle().getText("labelCreatedOn") + " " + sDate;
			
		},

		formatModificationInfo: function(sUser, dDate) {
			var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
				pattern: "yyyy/MM/dd"
			});
			var sDate = oDateFormat.format(dDate);
			return this.getModel("i18n").getResourceBundle().getText("labelModifiedBy") + " " + sUser
			+ ", " + this.getModel("i18n").getResourceBundle().getText("labelModifiedOn") + " " + sDate;
		}

	};

});